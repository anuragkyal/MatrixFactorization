Compiling the code:
javac PR.java

Running the code:
java PR < input.txt
